.. _Table-Of-Content-Video:

*video* module. Video analysis
-----------------------------------------------------------

Look here in order to find use on your video stream algoritms like: motion extraction, feature tracking and foreground extractions. 

.. include:: ../../definitions/noContent.rst

.. raw:: latex

   \pagebreak
